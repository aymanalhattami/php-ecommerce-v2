-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 29, 2016 at 12:25 PM
-- Server version: 5.7.9
-- PHP Version: 5.6.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `newwebsite`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
CREATE TABLE IF NOT EXISTS `cart` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `price` int(5) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '1',
  `total` int(11) NOT NULL,
  `path` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `name`, `price`, `quantity`, `total`, `path`) VALUES
(2, 'OMAX', 75, 10, 750, 'image/shop-images/shop2.jpg'),
(12, 'CASIO', 60, 1, 60, 'image/shop-images/shop12.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
CREATE TABLE IF NOT EXISTS `contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `subject` varchar(30) NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `subject`, `message`) VALUES
(31, 'osama', 'osama@gmail.com', 'subject1234546', 'message');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE IF NOT EXISTS `customer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fullName` varchar(40) COLLATE utf8_bin NOT NULL,
  `email` varchar(30) COLLATE utf8_bin NOT NULL,
  `password` varchar(30) COLLATE utf8_bin NOT NULL,
  `confirm` varchar(30) COLLATE utf8_bin NOT NULL,
  `phone` varchar(20) COLLATE utf8_bin NOT NULL,
  `address` varchar(50) COLLATE utf8_bin NOT NULL,
  `city` varchar(20) COLLATE utf8_bin NOT NULL,
  `country` varchar(20) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='for customers';

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `fullName`, `email`, `password`, `confirm`, `phone`, `address`, `city`, `country`) VALUES
(12, '&lt;p&gt;aymen&lt;/p&gt;', 'aymen12@gmail.com', '123456', '123456', '774885285', 'airport st', 'Sanaa', 'yemen'),
(10, 'ahmed ali', 'ahmed@gmail.com', '123456', '123456', '125478963', 'sanaa st.', 'hodidah', 'yemen'),
(7, 'aymen alhattamy', 'aymen@gmail.com', '123456', '123456', '774885285', 'airport st', 'sanaa', 'yemen'),
(11, 'omar ahmed', 'omar@gmail.com', '123456', '123456', '145287936', 'taiz st.', 'sanaa', 'yemen'),
(9, 'bassam ahmed', 'bassam@gmail.com', '123456', '123456', '45236971', 'hora', 'aden', 'yemen'),
(6, 'yasser ali', 'yasser@gmail.com', '123456', '123456', '142536789', 'mosaiq', 'sanaa', 'yemen'),
(13, '<p>aymen</p>', 'aymen13@gmail.com', '123456', '123456', '774885285', 'airport st', 'Sanaa', 'yemen'),
(14, 'osama elzero', 'osama@gmail.com', '123456', '123456', '258963147', 'sanaa st.', 'hodaida', 'yemen');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
CREATE TABLE IF NOT EXISTS `payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cardNumber` int(11) NOT NULL,
  `cvc` int(11) NOT NULL,
  `fullName` varchar(30) NOT NULL,
  `expiration` date NOT NULL,
  `amount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `cardNumber`, `cvc`, `fullName`, `expiration`, `amount`) VALUES
(1, 123456, 123, 'aymen alhattamy', '2020-12-12', 500),
(2, 123456, 123, 'aymen alhattamy', '2020-12-12', 500),
(3, 123123, 321, 'yasser ali', '2018-10-10', 400),
(4, 123123, 321, 'yasser ali', '2018-10-10', 400),
(5, 3214565, 369, 'aymen alhattamy', '2017-10-09', 300);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
CREATE TABLE IF NOT EXISTS `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `path` varchar(50) NOT NULL,
  `price` int(5) NOT NULL,
  `type` varchar(10) NOT NULL,
  `color` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT '10',
  `des` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `path`, `price`, `type`, `color`, `quantity`, `des`) VALUES
(1, 'CASIO', 'image/shop-images/shop1.jpg', 80, 'women', 'brown, black, orange, whilte', 10, 'elegant traditional watch for ladies loving watches from the Brand CASIO . Stylish enough to add charm to your personality. It carries warranty and attractive features with it.'),
(2, 'OMAX', 'image/shop-images/shop2.jpg', 75, 'women', 'blue, yellow, red', 10, 'elegant traditional watch for ladies loving watches from the Brand OMAX. Stylish enough to add charm to your personality. It carries warranty and attractive features with it.'),
(3, 'ICE', 'image/shop-images/shop3.jpg', 85, 'women', 'brown, black, red, whilte', 10, 'elegant traditional watch for  ladies loving watches from the Brand ICE. Stylish enough to add charm to your personality. It carries warranty and attractive features with it.'),
(4, 'ICE', 'image/shop-images/shop4.jpg', 75, 'women', 'brown, white, red, orange', 10, 'elegant traditional watch for ladies loving watches from the Brand ICE. Stylish enough to add charm to your personality. It carries warranty and attractive features with it.'),
(5, 'CASIO', 'image/shop-images/shop5.jpg', 100, 'men', 'black, brown, gray', 10, 'elegant traditional watch for gentel men loving watches from the Brand CASIO. Stylish enough to add charm to your personality. It carries warranty and attractive features with it.'),
(6, 'MAX', 'image/shop-images/shop6.jpg', 90, 'women', 'golden, gray, red, black', 10, 'elegant traditional watch for ladies loving watches from the Brand MAX. Stylish enough to add charm to your personality. It carries warranty and attractive features with it.'),
(7, 'CASIO', 'image/shop-images/shop7.jpg', 80, 'men', 'golden, gray, white', 10, 'elegant traditional watch for gentle men loving watches from the Brand CASIO. Stylish enough to add charm to your personality. It carries warranty and attractive features with it.'),
(8, 'OMAX', 'image/shop-images/shop8.jpg', 100, 'men', 'brown, black, white', 10, 'elegant traditional watch for gentle men loving watches from the Brand OMAX. Stylish enough to add charm to your personality. It carries warranty and attractive features with it.'),
(9, 'OMAC', 'image/shop-images/shop9.jpg', 95, 'men', 'black, white, brown', 10, 'elegant traditional watch for gentle men loving watches from the Brand OMAX. Stylish enough to add charm to your personality. It carries warranty and attractive features with it.'),
(10, 'Quartz', 'image/shop-images/shop10.jpg', 40, 'alert', 'red, blue, white, black, brown', 10, 'elegant traditional watch from the Brand Quartiz'),
(11, 'ICE', 'image/shop-images/shop11.jpg', 60, 'women', 'red, green, blue, white, black', 10, 'elegant traditional watch for ladies loving watches from the Brand ICE . Stylish enough to add charm to your personality. It carries warranty and attractive features with it.'),
(12, 'CASIO', 'image/shop-images/shop12.jpg', 60, 'women', 'white, black, red, gray', 10, 'elegant traditional watch for ladies  loving watches from the Brand CASIO . Stylish enough to add charm to your personality. It carries warranty and attractive features with it.'),
(13, 'Quartz', 'image/shop-images/shop13.jpg', 40, 'alert', 'gray, white, black, red', 10, 'elegant traditional watch from the Brand Quartiz'),
(14, 'OMAX', 'image/shop-images/shop14.jpg', 100, 'men', 'gray, white, black', 10, 'elegant traditional watch for gentle men loving watches from the Brand OMAX. Stylish enough to add charm to your personality. It carries warranty and attractive features with it.'),
(15, 'CASIO', 'image/shop-images/shop15.jpg', 100, 'men', 'black, brown', 10, 'elegant traditional watch for gentle men loving watches from the Brand CASIO. Stylish enough to add charm to your personality. It carries warranty and attractive features with it.'),
(16, 'MAX', 'image/shop-images/shop16.jpg', 50, 'alert', 'red, white, black, blue', 10, 'elegant traditional watch from the Brand MAX'),
(17, 'CASIO', 'image/home-images/side1.jpg', 120, 'men', 'black, brown', 10, 'elegant traditional watch for gentle men loving watches from the Brand CASIO . Stylish enough to add charm to your personality. It carries warranty and attractive features with it.'),
(18, 'OMAX', 'image/home-images/side2.jpg', 110, 'men', 'black, gray', 10, 'elegant traditional watch for gentle men loving watches from the Brand OMAX . Stylish enough to add charm to your personality. It carries warranty and attractive features with it.'),
(21, 'OMEGA', 'image/home-images/side5.jpg', 150, 'men', 'gray, black, white', 10, 'elegant traditional watch for gentle men loving watches from the Brand OMEGA . Stylish enough to add charm to your personality. It carries warranty and attractive features with it.'),
(22, 'OMEGA', 'image/home-images/side6.jpg', 140, 'men', 'golden, gray, balck', 10, 'elegant traditional watch for gentle men loving watches from the Brand OMEGA . Stylish enough to add charm to your personality. It carries warranty and attractive features with it.'),
(23, 'CASIO', 'image/home-images/side7.jpg', 85, 'men', 'brown, black,', 10, 'elegant traditional watch for gentle men loving watches from the Brand CASIO . Stylish enough to add charm to your personality. It carries warranty and attractive features with it.');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
